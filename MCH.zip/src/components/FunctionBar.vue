<template>
  <div>
    el
  </div>
</template>

<script>
export default {
  name: "FunctionBar"
}
</script>

<style scoped>

</style>
