<template>
  <div class="User">
    <div class="port-head">
      <div class="head-text">
        <span>管理员设置</span>
      </div>
      <div class="head-button">
        <el-button title="帮助"><i class="el-icon-notebook-1"></i></el-button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "User",
  data() {
    return {
      
    }
  },
  methods: {
    
  },
}
</script>

<style scoped>

</style>
