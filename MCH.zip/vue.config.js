module.exports = {
    devServer: {
        port: 8080
    },
    publicPath: '/hello/',
    assetsDir: 'static'
}